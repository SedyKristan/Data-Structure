#include <iostream>

using namespace std;

int main()
{
int choice;
bool gameOn = true;
while (gameOn != false){
cout << "Choose what to compute: \n ";
cout << "1 - Area of the square \n";
cout << " 2 - Area of rectangle\n";
cout << " 3 - Area of triangle\n";
cout << " 4 - Area of circle \n";
cout << " 5 - Exit \n";
cout << " Enter your choice and press return: ";

cin >> choice;

switch (choice)
{
case 1:
cout << "Enter side of square \n";
	int side, area1;
	cin >> side;
	area1 = side * side;
	cout << "Area of square is "<<area1<<endl;
break;
case 2:
cout << "Enter length: ";
	int width, length, area2;
	cin >> length;
cout << "Enter width: ";
	cin >> width;
	area2 = length * width;
	cout << "Area of rectangle is "<<area2<<endl;
break;
case 3:
cout << "Enter base: ";
	int base, height, area3;
	cin >> base;
cout << "Enter height: ";
	cin >> height;
	area3 = (base * height) / 2;
	cout << "Area of triangle is "<<area3<<endl;
break;
case 4:
cout << "Enter radius \n";
	double radius, area4;
	cin >> radius;
	area4 = (radius*radius)*3.14159265359;
	cout << "Area of circle is "<<area4<<endl;
break;
case 5:
cout << "Thank you! \n";
gameOn = false;
break;
default:
cout << "Not a Valid Choice. \n";
cout << "Choose again.\n";
cin >> choice;
break;
}

}
return 0;
}

