#include <iostream>
using namespace std;
int main()
{
	FILE *fp;
	fp=fopen("e:\\myfiles\\sample.txt", "w");
	//check permission if you can write a file
	if(!fp)
	{
		cout << "Cannot open file.\n";
		system("pause");
		exit(1);
	}
	//Prints the character ASCII value from 65 to 90 (A-Z) to a file
	for(int i=65;1<91; i++)
		fputc(i,fp);
	fclose(fp);
	return 0;
}
